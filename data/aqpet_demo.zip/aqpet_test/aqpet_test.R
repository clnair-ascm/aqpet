#' \Yuqing \Dai
# setup working directory
setwd("/Users/yqdai/Downloads/aqpet_test/")
#' clean working space
rm(list = ls(all = T))
#' load package
library(aqpet)
load_envir()
library(augsynth)
#'
###################################################################################################################################################################
#'
# ---- Global_Control_Panel ----
#'
GCP <- list(
            data_dir           = "/Users/yqdai/Downloads/aqpet_test/", # put all csv file in this folder
            file_pattern       = "*.csv", # csv or xlsx
            datetime_format    = "%d/%m/%Y %H:%M", # time format
            dependent_variable = "no2", # predictive variable
            data_timerange     = c("2018-04-01", "2018-10-31"), # time range
            wenormed        = F
            )
# ---- Weather_Normalised_Panel ----
WNP <- list(
            response_variable   = "no2",
            predictor_variables = c("trend", "month", "dow", "hour", "temp", "wd", "ws", "sp", "RH", "blh", "ssr"), # all predictive variables 
            constant_variables  = c("trend", "month", "dow"), # constant variable for deweather
            miss_data_treat     = "rm", # Options: "linear", "mean", "median"
            split_proportion    = 0.8,
            split_by_time       = FALSE,
            seed                = 123,
            max_models          = 15, # maximum number of models trained
            max_runtime_secs    = 150,
            max_mem_size        = "20g",
            wenorm_method       = "default",
            num_iterations      = 50, # resampling times
            algorithm           = "gbm", # final algorithm
            criterion           = "AUTO",
            write_out           = F, # save or not
            kill_h2o            = F,
            out_dir             = "/Users/yqdai/Downloads/aqpet_test/",
            cpd                 = F, # F by default
            window              = 2
          )

# ---- Synthetic_Control_Panel ----
#'
SCP <-  list(
          treatment_group  = c("North_Kensington"), # Important
          start_time       = c("2018-06-08"),
          end_time         = c("2018-09-15"),
          buffer_time      = NULL, # NOT USED
          split_proportion = 0.8, # NOT USED
          split_by_time    = FALSE, # NOT USED
          seed             = 123, # NOT USED
          max_models       = 7, # NOT USED
          max_runtime_secs = 120, # NOT USED
          algorithm        = "gbm", # NOT USED
          criterion        = "AUTO" # NOT USED
        )
#'
##################################################################################################################################################################
#' Read in data as a list
data_pretreated <- read_data(GCP)
#'
#' plot original time trend. 
# time_trend(data_pretreated$df_origin, time_resolution = "7 day")
#'
#' Run deweather function
data_treated <- buildMod(mylist = data_pretreated,
                          params = WNP
                        )
#'
#' plot deweathered time trend and site data
# time_trend(data_treated$data_final)
# time_trend(data_treated$list_df[[2]], time_resolution = "7 day")
#'
#' Check if there are any missing data for the data
show_missing(data_treated$data_final, date_col = datetime, date = T)
#' Calculate 3-day average to ignore the missing data
data_prepared <- time_aggregation(df = data_treated$data_final, time_resolution = "3 day")
#' Check again
show_missing(data_prepared, date_col = datetime, date = T)
#' ASCM analysis
data_ascm   <- a_scm(df = data_prepared,
                     cpd = F, 
                     window = 10,
                     params = SCP)
#' plot the intervention effect
ascm_trend(data_ascm$df_North_Kensington, y_variable = "Estimate", 
          title = "",
          ylim = c(-15, 40),
          ylab = "Estimate",
          text_size = 1.5,
          add_ribbon = T,
          start_times = SCP$start_time)